import pytest

def test_init():
    assert 1 == 1
