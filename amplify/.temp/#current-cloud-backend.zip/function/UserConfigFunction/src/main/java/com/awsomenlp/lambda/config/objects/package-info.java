/**
 *
 */

package com.awsomenlp.lambda.config.objects;
