/**
 *
 */

package com.awsomenlp.lambda.config.resolvers;
